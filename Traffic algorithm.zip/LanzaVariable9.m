clear;close all;clc;

% N�mero de nodos
n = 9;

% Matriz de conectividad: explica qu� nodos est�n conectados con qu� nodos
CONEC=xlsread('Matriz_trafico_rel_9.xlsx','M1:U9');

%Destino deseado del tr�fico de cada nodo (valor entre 0 y 1)
OBJETrel=xlsread('Matriz_trafico_rel_9.xlsx','A1:I9');

% Carriles
Carriles=xlsread('Matriz_trafico_rel_9.xlsx','N14:V22');

% Distancias
Distancias=xlsread('Matriz_trafico_rel_9.xlsx','A14:I22');
Distancias = Distancias./max(max(Distancias));

% Trafico en cada nodo
TRAF = xlsread('Matriz_trafico_rel_9.xlsx','A27:I35');
trafnodo=diag(TRAF)/max(max(TRAF));

% OBJETabs guarda el n�mero absoluto de trafico entre cada nodo
OBJETabs=trafnodo*ones(1,length(trafnodo)).*OBJETrel;
TablaVerdad=combinaciones([1 2 3],sum(sum(CONEC))/2);


save('DatosPosibles9');
