%%% Esta script optimiza globalmente toda la matriz y calcula el optimo

clear;close all;clc
load('DatosPosibles7');
% Matriz de conectividad: CONEC
% Matriz de Carriles: Carriles
% Matriz de Distancias: Distancias
% Matriz de tr�fico absoluto en cada nodo: OBJETabs
% Matriz de dispersi�n relativa en cada ruta: OBJETrel
% Tabla de verdad: Tabla Verdad
% N�mero de nodos: n
% Traffic matrix: Transit (cars per hour per lane)

% Initial condition
Lanes = Carriles;
[ Transit ] = initial_SmartTraffic( CONEC,Distancias,OBJETabs,Lanes,n );
OBJETabsini = OBJETabs;    % We start with 0 per node, but we um inside the loop
OBJETabs = zeros(n);    % We start with 0 per node, but we um inside the loop
Identity = eye(n); % This is used to remove the diagonal part of traffic matrix: people who has reach their destinity

    for k = 1:n
        OBJETabs = OBJETabs + OBJETabsini; % We sum a new block of traffic
        Velocities = (50 - 49*sin(pi/2*(Transit-1e3)/9e3)*(Transit > 1e3))*(Transit <= 1e4) + (Transit > 1e4);
        Cost = Distancias./Velocities;
        Transit = zeros(n);
        INCTRAF = zeros(n);
        for i=1:n % Rows (origin)
            for j=1:n % Columns (Destination)
                if (i ~= j) && (OBJETabs(i,j) > 0)
                    path = buscar_camino_fast(CONEC,i,j,Cost);
                    INCTRAF(path(2),j) = INCTRAF(path(2),j) + OBJETabs(i,j);
                    Transit(path(1),path(2)) = Transit(path(1),path(2)) + OBJETabs(i,j)/Lanes(path(1),path(2));
                end
            end
        end
        OBJETabs = INCTRAF - INCTRAF.*Identity;
    end

    count = 0;
    prom0 = 1;
    prom1 = 0;
    sumvar = 0;
    sumcost = 0;
    total_cost = 0;
    
    while abs(prom1-prom0)/prom0 > 0.01
        prom0 = prom1; % Now, prom0 is the previous mean
        % Hay que mover a la gente de A a su destino  (por ejemplo C)
        % sin machacar la matriz inicial durante los bucles porque al
        % mover la gente de C estar�an los nuevos tambi�n.
        
        % Los bucles for van a calcular los movimientos, por tanto al
        % acabar los bucles, se machaca la matriz inicial
        
        % Los bucles for calculan todos los caminos optimos de todos los
        % puntos a todos los puntos, partiendo de la matriz inicial
        
        % FILAS QUIEREN IR A COLUMNAS
        %COSTES = Distancias.*(0.3 + MatMinVar)./Carriles; % Ponderar costes
        OBJETabs = OBJETabs + OBJETabsini; % We sum a new block of traffic
        Velocities = (50 - 49*sin(pi/2*(Transit-1e3)/9e3)*(Transit > 1e3))*(Transit <= 1e4) + (Transit > 1e4);
        Cost = Distancias./Velocities;
        Transit = zeros(n);
        INCTRAF = zeros(n);
        for i=1:n % Rows (origin)
            for j=1:n % Columns (Destination)
                if (i ~= j) && (OBJETabs(i,j) > 0)
                    path = buscar_camino_fast(CONEC,i,j,Cost);
                    sumcost = sumcost + OBJETabs(i,j)*Cost(path(1),path(2));
                    INCTRAF(path(2),j) = INCTRAF(path(2),j) + OBJETabs(i,j);
                    Transit(path(1),path(2)) = Transit(path(1),path(2)) + OBJETabs(i,j)/Lanes(path(1),path(2));
                end
            end
        end
        OBJETabs = INCTRAF - INCTRAF.*Identity;
        sumvar = sumvar + var(Transit(CONEC > 0));
        count = count + 1;
        prom1 = sumvar/count;
    end
    promcost = sumcost/count;
    MeritFigure = [prom1, promcost];


%  fprintf('Recorrido total: %f km\nCoste total: %f\nVarianza: %f\nVelocidad: %f\n',recorrido*7,l2,l1,recorrido/l2);