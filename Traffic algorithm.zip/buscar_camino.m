function [camino, valmin] = buscar_camino( MatCon,Or,Dest,costes)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

vector = Or;
cond=1;
while sum(cond)
    vector0 = vector;
    vector = [];
    for i=1:length(vector0(:,end))
        if (vector0(i,end)==Dest)||(vector0(i,end)==0)
            vector=[vector;[vector0(i,:),0]];
        else
            pos = vector0(i,end);
            posibles=find(MatCon(pos,:));
            %         posibles(posibles==Or) = []; % Ampliar esta condicionfila i
            for q=1:length(vector0(i,:))
                posibles(posibles==vector0(i,q)) = []; % Ampliar esta condicionfila i
            end
            base = vector0(i,:);
            %         for q=1:length(base)
            %         posibles(posibles==base(q)) = []; % Ampliar esta condicionfila i
            %         end
            vector2 = ones(length(posibles),1)*base;
            vector2 = [vector2, posibles'];
            vector = [vector; vector2];
            cond=~((vector(:,end)==Dest)|(vector(:,end)==0));
        end
    end
end

% col = size(vector,2);
% prov = vector';
% pos = find(prov(:) == Dest);
% pos = round(pos(1)/col);
%
% camino = vector(pos,:);
p=size(vector);
suma=zeros(p(1),1);
for r=1:p(1)
    for k=1:p(2)-1
        if vector(r,k+1)==0
            break;
        end
        suma(r)=suma(r)+costes(vector(r,k),vector(r,k+1));
    end
end
[valmin,posmin]=min(suma);
valmin=costes(vector(posmin,1),vector(posmin,2));
camino=vector(posmin,:);
camino(camino==0)=[];
end

