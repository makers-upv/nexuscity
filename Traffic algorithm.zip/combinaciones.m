function [ TablaVerdad ] = combinaciones( vect,n )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

base = length(vect);

TablaVerdad = zeros(base^n,n);

for i=1:n % Columna
    repeticiones = base^(n-i);
    
    % Vector auxiliar cada numero repetido base^(columna-1)
    aux = ones(base^(i-1),1)*vect;
    % La longitud del tocho a repetir en for j es de filas base^(columna)
    aux = aux(:);
    % Ahora he de repetir base^columna veces el tocho aux
    numfilas = base^i;
    for j=1:repeticiones % Rellenar las final para la columna i
        TablaVerdad(numfilas*(j-1)+1:numfilas*j , end-i+1) = aux;
    end
    
end


end

