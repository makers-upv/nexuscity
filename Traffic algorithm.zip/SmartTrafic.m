%%% Esta script optimiza globalmente toda la matriz y calcula el optimo

clear;close all;clc
load('DatosPosibles7');
% Matriz de conectividad: CONEC
% Matriz de Carriles: Carriles
% Matriz de Distancias: Distancias
% Matriz de tr�fico absoluto en cada nodo: OBJETabs
% Matriz de dispersi�n relativa en cada ruta: OBJETrel
% Tabla de verdad: Tabla Verdad
% N�mero de nodos: n
% Traffic matrix: Transit (cars per hour per lane)

VarianzaNormal = 1.9053e+06;
CosteNormal = 463.4721;
VarianzaGPS = 1.9053e+06;
CosteGPS = 691.4000;

% Initial condition
[ Transit ] = initial_SmartTraffic( CONEC,Distancias,OBJETabs,Carriles,n );

OBJETabsini = OBJETabs; % Initial condition to refresh the traffic
Mat0 = zeros(n);
OBJETabs = Mat0;    % We start with 0 per node, but we um inside the loop
TransitIni  = Transit;  % Initial condition to refresh the traffic

long = length(TablaVerdad);
Identity = eye(n); % This is used to remove the diagonal part of traffic matrix: people who has reach their destinity
MeritFigure = zeros(long,2);
% We will try to minimce the variance of Transit matrix

for b=1:long
     Lanes  = colocar(TablaVerdad(b,:),CONEC,4); % We take the actual lanes
     Transit = TransitIni; % We refresh initial condition
     OBJETabs = Mat0;

    for k = 1:n
        OBJETabs = OBJETabs + OBJETabsini; % We sum a new block of traffic
        Velocities = (50 - 49*sin(pi/2*(Transit-1e3)/9e3)*(Transit > 1e3))*(Transit <= 1e4) + (Transit > 1e4);
        Cost = Distancias./Velocities;
        Transit = zeros(n);
        INCTRAF = zeros(n);
        for i=1:n % Rows (origin)
            for j=1:n % Columns (Destination)
                if (i ~= j) && (OBJETabs(i,j) > 0)
                    path = buscar_camino_fast(CONEC,i,j,Cost);
                    INCTRAF(path(2),j) = INCTRAF(path(2),j) + OBJETabs(i,j);
                    Transit(path(1),path(2)) = Transit(path(1),path(2)) + OBJETabs(i,j)/Lanes(path(1),path(2));
                end
            end
        end
        OBJETabs = INCTRAF - INCTRAF.*Identity;
    end

    count = 0;
    prom0 = 1;
    prom1 = 0;
    sumvar = 0;
    sumcost = 0;
    total_cost = 0;
    
    while abs(prom1-prom0)/prom0 > 0.01
        prom0 = prom1; % Now, prom0 is the previous mean
        % Hay que mover a la gente de A a su destino  (por ejemplo C)
        % sin machacar la matriz inicial durante los bucles porque al
        % mover la gente de C estar�an los nuevos tambi�n.
        
        % Los bucles for van a calcular los movimientos, por tanto al
        % acabar los bucles, se machaca la matriz inicial
        
        % Los bucles for calculan todos los caminos optimos de todos los
        % puntos a todos los puntos, partiendo de la matriz inicial
        
        % FILAS QUIEREN IR A COLUMNAS
        %COSTES = Distancias.*(0.3 + MatMinVar)./Carriles; % Ponderar costes
        OBJETabs = OBJETabs + OBJETabsini; % We sum a new block of traffic
        Velocities = (50 - 49*sin(pi/2*(Transit-1e3)/9e3)*(Transit > 1e3))*(Transit <= 1e4) + (Transit > 1e4);
        Cost = Distancias./Velocities;
        Transit = zeros(n);
        INCTRAF = zeros(n);
        for i=1:n % Rows (origin)
            for j=1:n % Columns (Destination)
                if (i ~= j) && (OBJETabs(i,j) > 0)
                    path = buscar_camino_fast(CONEC,i,j,Cost);
                    sumcost = sumcost + OBJETabs(i,j)*Cost(path(1),path(2));
                    INCTRAF(path(2),j) = INCTRAF(path(2),j) + OBJETabs(i,j);
                    Transit(path(1),path(2)) = Transit(path(1),path(2)) + OBJETabs(i,j)/Lanes(path(1),path(2));
                end
            end
        end
        OBJETabs = INCTRAF - INCTRAF.*Identity;
        sumvar = sumvar + var(Transit(CONEC > 0));
        count = count + 1;
        prom1 = sumvar/count;
    end
    promcost = sumcost/count;
    MeritFigure(b,:) = [prom1, promcost];
    
    if ~mod(b,1000)
        fprintf('%5.2f%%\n',b/long*100);
    end
    
end

%% We find the minimum

pos = find(MeritFigure(:,2) <= CosteNormal);
prov = MeritFigure(pos,1);
minval = inf;
minpos = 1;
for i=1:length(pos)
    if minval > MeritFigure(pos(i),1)
        minval = MeritFigure(pos(i),1);
        minpos = pos(i);
    end
end
Carriles  = colocar(TablaVerdad(minpos,:),CONEC,4);

save('Optimum.mat','Carriles','-append');