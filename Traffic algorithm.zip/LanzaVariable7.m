clear;close all;clc;

% N�mero de nodos
n = 7;

% Matriz de conectividad: explica qu� nodos est�n conectados con qu� nodos
CONEC=xlsread('Matriz_trafico_rel_7.xlsx','O2:U8');

%Destino deseado del tr�fico de cada nodo (valor entre 0 y 1)
OBJETrel=xlsread('Matriz_trafico_rel_7.xlsx','B1:H7');

% Carriles
Carriles=xlsread('Matriz_trafico_rel_7.xlsx','O14:U20');

% Distancias
Distancias=xlsread('Matriz_trafico_rel_7.xlsx','B15:H21');

% Trafico en cada nodo
TRAF = xlsread('Matriz_trafico_rel_7.xlsx','B27:H33');
trafnodo=diag(TRAF);

% OBJETabs guarda el n�mero absoluto de trafico entre cada nodo
OBJETabs=trafnodo*ones(1,length(trafnodo)).*OBJETrel;
TablaVerdad=combinaciones([1 2 3],sum(sum(CONEC))/2);


save('DatosPosibles7');