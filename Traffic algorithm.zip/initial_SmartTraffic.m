function [ Transit ] = initial_SmartTraffic( CONEC,Distancias,OBJETabs,Carriles,n  )
%initial_SmartTraffic Computes the initial transit condition for SmarTraffic,
%according to a GPS solver

% Hay que mover a la gente de A a su destino  (por ejemplo C)
% sin machacar la matriz inicial durante los bucles porque al
% mover la gente de C estar�an los nuevos tambi�n.

% Los bucles for van a calcular los movimientos, por tanto al
% acabar los bucles, se machaca la matriz inicial

% Los bucles for calculan todos los caminos optimos de todos los
% puntos a todos los puntos, partiendo de la matriz inicial

% FILAS QUIEREN IR A COLUMNAS
COST = Distancias; % Shortest path
Transit = zeros(n); % Initizalize transit matrix
for i=1:n % Filas
    for j=1:n %Columnas
        if (i ~= j) && (OBJETabs(i,j) > 0)
            path = buscar_camino_fast(CONEC,i,j,COST);
            Transit(path(1),path(2)) = Transit(path(1),path(2)) + OBJETabs(i,j)/Carriles(path(1),path(2));
        end
    end
end

end

