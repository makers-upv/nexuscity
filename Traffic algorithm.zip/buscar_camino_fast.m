function [camino, valmin] = buscar_camino_fast( MatCon,Or,Dest,costes)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

vector = [0 Or];
cont = 1;
camino = [inf Or];

% En la primera columna de cada ruta se va a guardar el coste, menos en el
% camino llegado de coste minimo

% He de guardar de los que hayan llegado el minimo
% De los que no hayan llegado solo guardar los menores estrictos que el min


while cont
    vector0 = vector;
    vector = [];
    for i=1:length(vector0(:,end))
        costeruta = vector0(i,1);
        base = vector0(i,:);
        pos = base(end);
        posibles=find(MatCon(pos,:));
        % Nos quitamos las combinaciones ya recorridas
        for q=2:length(base)
            posibles(posibles==base(q)) = []; % Ampliar esta condicionfila i
        end
        vector2 = [];
        cont = 0;
        for q=1:length(posibles) % Esta es la puta clave
            costeruta_q = costeruta + costes(pos,posibles(q));
            % Solo a�adimos si el coste de la ruta es menor que el min
            if costeruta_q < camino(1)
                % Puede haber llegado a destino o no
                if posibles(q) == Dest % Ha lleado a destino
                    camino = [vector0(i,:), Dest];
                    camino(1) = costeruta_q;
                else % No ha llegado, pero hay que concatenar
                    cont = cont + 1;
                    vector2 = [vector2; [costeruta_q base(2:end) posibles(q)]];
                end
            end
        end
        vector = [vector; vector2];
    end
end

valmin=camino(1);
camino(1) = [];
end

