function matriz=colocar(vector,CONEC,n)
a=find(CONEC==1);
matriz=zeros(size(CONEC));
indice=[];
[fil,col]=ind2sub(size(CONEC),a);
for i=1:length(fil)
    if col(i) > fil(i)
        indice=[indice,i];
    end
end
fil(indice)=[];
col(indice)=[];

for j=1:length(fil)
    matriz(fil(j),col(j))=n-vector(j);
    matriz(col(j),fil(j))=vector(j);
    
end

end