function [OptimaCons, OptimaGen] = Optimizacion_baterias(MatGen,EdiBat,Coord)
%%% EXPLICACI�N DE DONDE SE OBTIENEN LOS COSTES %%%%%%%
% - Pondera la distancia
% - Es m�s �ptimo tomar de placas solares que de bater�as
% - Primero van las bater�as con menos carga
% Coste_consumir = a*distancia + b*Bateria + c*(~carga)
% Coste_generar  = a*distancia + b*Bateria + c*carga
% Ponderamos a b c \. a + b + c = 1;
% a = 0.7
% b = 0.1
% c = 0.2
a = 0.8; b = 0.2; c = 0.15;

%%% Datos de entrada
% % Matriz que define que edifcios generan (0) y consumen (1) bateria (2)
% MatGen = [0 2 1 2 0 1 0];
% % Edificios que tienen baterias y porcentaje de carga
% EdiBat = [0 0.2 0 0.4 0 0 0];
% % Matriz de distancias entre edificios
% Coord = [0 7; 4 6; 2 3; 5 0; 4 3; 2 1; 0 2];
%


%%% Preproceso
n = length(MatGen); % N� de edificos
Distancias = zeros(n);
% Calculamos todas las combinaciones de distancias
for i=1:n
    for j=i+1:n
        Distancias(i,j) = sqrt( (Coord(i,1)-Coord(j,1))^2 + (Coord(i,2)-Coord(j,2))^2 );
    end
end
Distancias = Distancias./max(max(Distancias)); % Adimensionalizaci�n
Distancias = Distancias + Distancias'; % Sim�trica



%%% Localizar tipos de edificios
fuentes   = find(MatGen==0); % Generadores
sumideros = find(MatGen==1); % Consumidores
baterias  = find(MatGen==2); % Baterias



%%%%%%%%%%%%%%%% Codigo consume %%%%%%%%%%%%%%%%%%%%%%

% Solo puede ir a edificio que generan y a baterias
Carga = Distancias*0;
Paneles = Carga;
for i=1:length(baterias)
    Paneles(:,baterias(i)) = 1;
    Carga  (:,baterias(i)) = EdiBat(baterias(i));
end
CosteCons = (a*Distancias + b*Paneles).*(1-Carga+c)/(1+c); % Coste = distancias

% Las baterias son permutaciones con repeticion, y los generadores lo son
% sin repeticion
comb = comb_rep_norep([baterias fuentes],length(sumideros),baterias);

costemin = inf;
for j=1:length(comb) % Filas de combinaciones
    coste = 0;
    for k=1:length(sumideros) % Columnas de combinaciones
        coste = coste + CosteCons(sumideros(k),comb(j,k));
    end
    if coste < costemin
        costemin = coste;
        optima = comb(j,:);
    end
end
OptimaCons = [sumideros; optima];



%%% Codigo transicion
% Comparar las de optima y quitar los generadores que ya abastecen y las baterias
for i = 1:length(optima)
    fuentes( fuentes == optima(i) | MatGen(fuentes)==2 ) = [];
end



%%% Codigo genera
% Hay que ver las fuentes que nos quedan que baterias es optimo que
% recarguen
CosteGen = (a*Distancias + b*Paneles).*(Carga+c)/(1+c);

comb = combinaciones(baterias,length(fuentes));

costemin = inf;
for j=1:size(comb,1) % Filas de combinaciones
    coste = 0;
    for k=1:length(fuentes) % Columnas de combinaciones
        coste = coste + CosteGen(fuentes(k),comb(j,k));
    end
    if coste < costemin
        costemin = coste;
        optima = comb(j,:);
    end
end

OptimaGen = [fuentes; optima];
end