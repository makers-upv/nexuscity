CoordGeneradores    = xlsread('Edificios Malilla.xlsx','A3:C34');
CoordConsumidores  = xlsread('Edificios Malilla.xlsx','E3:G18');
indicesGen = 1:2:size(CoordGeneradores,1);
indicesCon = 1:4:size(CoordConsumidores,1);
CoordGeneradores = CoordGeneradores(indicesGen,:);
CoordConsumidores = CoordConsumidores(indicesCon,:);
CoordBaterias= xlsread('Edificios Malilla.xlsx','I3:K3');
CargaBaterias = xlsread('Edificios Malilla.xlsx','L3:N3');
BatLen = size(CargaBaterias,1);
GenLen = size(indicesGen,2);
ConLen = size(indicesCon,2);

Coord  = [CoordBaterias(:,2:3); CoordGeneradores(:,2:3); CoordConsumidores(:,2:3)];
MatGen  = [2*ones(1,size(CoordBaterias,1)) zeros(1,size(CoordGeneradores,1)) ones(1,size(CoordConsumidores,1))];

hora = 1;
EdiBat = [CargaBaterias(:,hora)' zeros(1,size(CoordGeneradores,1)) zeros(1,size(CoordConsumidores,1))];


[OptimaCons, OptimaGen] = Optimizacion_baterias(MatGen,EdiBat,Coord);

ax = axes('nextplot','add','ydir','reverse');

for i=1:size(CoordBaterias,1)
    plot(CoordBaterias(i,2),CoordBaterias(i,3),'.k','MarkerSize',25);
end
for i=1:length(CoordConsumidores)
    plot(CoordConsumidores(i,2),CoordConsumidores(i,3),'.r','Color',[200 58 55]/255,'MarkerSize',25);
    p(i) = plot(CoordConsumidores(i,2),CoordConsumidores(i,3),'--m','LineWidth',1);
end
for i=1:length(CoordGeneradores)
    plot(CoordGeneradores(i,2),CoordGeneradores(i,3),'.g','Color',[157 200 128]/255,'MarkerSize',25);
    q(i) = plot(CoordGeneradores(i,2),CoordGeneradores(i,3),'--b','LineWidth',1);
end

for j=1:length(OptimaCons)
    set(p(j),'XData',[Coord(OptimaCons(1,j),1) Coord(OptimaCons(2,j),1)],'YData',[Coord(OptimaCons(1,j),2) Coord(OptimaCons(2,j),2)]);
end

for j=1:length(OptimaGen)
    set(q(j),'XData',[Coord(OptimaGen(1,j),1) Coord(OptimaGen(2,j),1)],'YData',[Coord(OptimaGen(1,j),2) Coord(OptimaGen(2,j),2)]);
end

axis equal;
axis off;

indicesCon(OptimaCons(1,:) - (GenLen + BatLen) )
indicesGen(OptimaCons(2,:) - (BatLen) )

indicesGen(OptimaGen(1,:) - (BatLen) )
