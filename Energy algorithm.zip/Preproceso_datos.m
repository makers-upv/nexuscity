CoordBaterias  = xlsread('BateriasEdificios.xlsx','C3:D6');
CoordEdificios = xlsread('BateriasEdificios.xlsx','G3:H12');

Coord  = [CoordBaterias; CoordEdificios];
MatGen = [zeros(1,length(CoordBaterias)) ones(1,length(CoordEdificios))];

CargaBaterias = xlsread('Carga Baterias.xlsx','B3:E26');
ax = axes('nextplot','add');

for i=1:length(CoordBaterias)
    plot(CoordBaterias(i,1),CoordBaterias(i,2),'.b','MarkerSize',25);
end
for i=1:length(CoordEdificios)
    plot(CoordEdificios(i,1),CoordEdificios(i,2),'.r','MarkerSize',25);
    p(i) = plot(CoordEdificios(i,1),CoordEdificios(i,2),'--c','LineWidth',1);
end
set(gcf,'COlor','w')
axis off;
for i=1:24
    
EdiBat = [CargaBaterias(i,:) zeros(1,length(CoordEdificios))];
Optima = Optimizacion_baterias_simplificado(MatGen,EdiBat,Coord);

for j=1:length(Optima)
    set(p(j),'XData',[Coord(Optima(1,j),1) Coord(Optima(2,j),1)],'YData',[Coord(Optima(1,j),2) Coord(Optima(2,j),2)]);
end
end
