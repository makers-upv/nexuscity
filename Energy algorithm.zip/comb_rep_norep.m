function [ vector ] = comb_rep_norep( base,n,rep )
%comb_rep_norep Devuelve las combinaciones del vector base en n casos,
%asumiento que los valores del vector rep (deben aparecer en base) se
%pueden repetir

base = base(:);
noeliminar = rep(:);

eliminar = base;
for i=1:length(noeliminar)
    eliminar(eliminar == noeliminar(i)) = [];
end

vector = base;

for i=1:n-1
    vector2 = [];
    for j=1:length(vector)
        posiciones = vector(j,:);
        eliminar0 = eliminar;
        for k=1:length(posiciones)
            eliminar0(eliminar0 == posiciones(k)) = [];
        end
        eliminar0 = [eliminar0; noeliminar];
        vector2 = [vector2; [ones(length(eliminar0),1)*posiciones, eliminar0] ];
    end
    vector = vector2;
end