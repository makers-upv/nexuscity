function [ Mat ] = perm_norep( v,n )
%perm_norep Permutation with no repetition
if n==1
    Mat = v(:);
else
    l = length(v);
    
    % Number of time a number is repeated
    for i=1:n-1
        p(i) = factorial_quotient(l-i,l-n);
    end
    p(end+1) = 1;
    
    % Number of times a sequence is repeated
    for i=2:n
        q(i) = factorial_quotient(l,l-i+1);
    end
    q(1) = 1;
    
    % How much a sequence occupies
    r(1) = factorial_quotient(l,l-n);
    for i=2:n
        r(i) = r(i-1)/(l-i+2);
    end
    
    
    Mat = zeros(factorial_quotient(l,l-n),n);
    
    for i=1:n % Each column
        for j=1:q(i) % Number of times we have to repeat a sequence
            vect = v;
            for k=1:i-1 % We have to move backwards to look which numbers have survived
                num = Mat(r(i)*(j-1)+1,k);
                vect(vect==num) = []; % Eliminate the position
            end
            prov = (ones(p(i),1)*vect);
            Mat(r(i)*(j-1)+1:r(i)*j,i) = prov(:);
        end
    end
end
end

function f = factorial_quotient(a,b)
%factorial_quotient Returns the quotient a!/b!
    f = prod(b+1:a);
end
    


